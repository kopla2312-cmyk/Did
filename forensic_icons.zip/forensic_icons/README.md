# Forensic icons pack (floor-plan constructor sprites)

100 flat 2D top-down PNG icons with transparent (alpha) background, 1024x1024,
style matched to floor-plan constructor sprites (flat, minimal, monochrome + one accent).

Categories (folders):
- ruk       (10) - hand / finger / palm traces
- nog       (12) - foot, shoe and vehicle track traces
- orudiya   (14) - tool and break-in marks (screwdriver, crowbar, axe, lock, ...)
- ognestrel (10) - firearms, bullets, cartridges, gunshot traces
- holodnoe  (12) - cold weapons and tools (knife, axe, hammer, bat, ...)
- bio       (12) - blood and biological traces
- prochie   (12) - other traces and stains (cigarette, paint, glass, scratches, ...)
- objekty   (18) - evidence objects and forensics gear (marker, scale, UV light, ...)

manifest.csv maps every file to its category and English description.
_contact_sheet.png shows all icons on a gray background.
